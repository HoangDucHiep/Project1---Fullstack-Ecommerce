import{cg as o}from"./main-DqC_vvY2.js";const e=t=>r=>r&&o(t,r)||"—";export{e as t};
//# sourceMappingURL=translationFormatter-CDzjmAGb.js.map

import{c as s}from"./main-DqC_vvY2.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-BISGad6J.js.map

import{aw as e,av as o}from"./main-DqC_vvY2.js";import*as m from"react";import{s as i}from"./DataListItemRow-CM57Q3-A.js";const l=s=>{var{children:a,className:t=""}=s,r=e(s,["children","className"]);return m.createElement("div",Object.assign({className:o(i.dataListItemControl,t)},r),a)};l.displayName="DataListControl";export{l as D};
//# sourceMappingURL=DataListControl-RRK2i-B6.js.map

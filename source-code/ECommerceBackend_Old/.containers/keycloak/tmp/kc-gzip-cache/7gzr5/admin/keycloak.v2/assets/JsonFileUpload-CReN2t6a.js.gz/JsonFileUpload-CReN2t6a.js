import{jsx as e}from"react/jsx-runtime";import{F as s}from"./FileUploadForm-B12jNon4.js";const t=({onChange:n,...o})=>e(s,{...o,language:"json",extension:".json",onChange:a=>{try{n(JSON.parse(a))}catch{n({}),console.warn("Invalid json, ignoring value using {}")}}});export{t as J};
//# sourceMappingURL=JsonFileUpload-CReN2t6a.js.map

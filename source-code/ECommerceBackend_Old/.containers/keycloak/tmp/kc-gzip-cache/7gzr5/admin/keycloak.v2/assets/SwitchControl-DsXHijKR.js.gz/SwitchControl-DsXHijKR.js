import{jsx as a}from"react/jsx-runtime";import{a as r,$ as n}from"./main-DqC_vvY2.js";const l=t=>{const{t:o}=r();return a(n,{...t,labelOn:o("on"),labelOff:o("off")})};export{l as D};
//# sourceMappingURL=SwitchControl-DsXHijKR.js.map

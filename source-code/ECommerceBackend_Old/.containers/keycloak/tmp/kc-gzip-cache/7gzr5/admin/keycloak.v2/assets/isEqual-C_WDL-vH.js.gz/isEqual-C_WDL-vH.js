import{ej as s}from"./main-DqC_vvY2.js";function i(a,r){return s(a,r)}export{i};
//# sourceMappingURL=isEqual-C_WDL-vH.js.map
